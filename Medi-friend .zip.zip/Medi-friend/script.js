// =======================
// Medi-Friend 💊 Reminder Script with EmailJS + Voice Alert
// =======================

// Initialize EmailJS
(function() {
  emailjs.init("6-rbGYIp33BmLHMvB"); // <-- Your Public Key
})();

// Handle Reminder Form
document.getElementById("reminderForm").addEventListener("submit", function(e) {
  e.preventDefault();

  const medName = document.getElementById("medName").value.trim();
  const dosage = document.getElementById("dosage").value.trim();
  const time = document.getElementById("time").value;

  if (!medName || !dosage || !time) {
    alert("Please fill all fields!");
    return;
  }

  addReminder(medName, dosage, time);
  scheduleNotification(medName, dosage, time);
  sendEmailReminder(medName, dosage, time);

  document.getElementById("reminderForm").reset();
});

// Add Reminder to UI
function addReminder(name, dosage, time) {
  const list = document.getElementById("reminderList");
  const item = document.createElement("div");
  item.className = "p-3 bg-blue-100 rounded-lg shadow";
  item.textContent = `${name} - ${dosage} at ${time}`;
  list.appendChild(item);
}

// Local Notification + Voice Alert
function scheduleNotification(name, dosage, time) {
  Notification.requestPermission().then(perm => {
    if (perm === "granted") {
      const now = new Date();
      const [h, m] = time.split(":");
      const reminderTime = new Date();
      reminderTime.setHours(h, m, 0, 0);

      const delay = reminderTime - now;
      if (delay > 0) {
        setTimeout(() => {setTimeout(() => {
  // Desktop notification
  new Notification("💊 Medi-Friend Reminder", {
    body: `${medicineName} - ${dosage}`,
    icon: "https://cdn-icons-png.flaticon.com/512/2965/2965567.png"
  });

  // Console log (to verify trigger)
  console.log("🔔 Reminder triggered for:", medicineName);

  // Voice reminder (after short delay)
  setTimeout(() => {
    speakReminder(medicineName, dosage);
  }, 300);

  // Email notification
  sendEmailReminder(medicineName, dosage, time);

}, delay);

          // Desktop Notification
          new Notification("💊 Time to take your medicine!", {
            body: `${name} - ${dosage}`,
            icon: "https://cdn-icons-png.flaticon.com/512/2965/2965567.png"
          });

          // Voice Reminder
          const message = new SpeechSynthesisUtterance(
            `Hey Keerthana, it's time to take your medicine ${name}. Dosage: ${dosage}.`
          );
          message.lang = "en-IN";
          speechSynthesis.speak(message);

        }, delay);
      }
    }
  });
}

// Send Email using EmailJS
function sendEmailReminder(name, dosage, time) {
  const params = {
    to_name: "Keerthana",
    medicine_name: name,
    dosage: dosage,
    time: time
  };

  emailjs
    .send("service_8glx8be", "template_lk7ee3b", params)
    .then(() => {
      console.log("✅ Email sent successfully!");
    })
    .catch((error) => {
      console.error("❌ Email failed:", error);
      alert("Email sending failed. Check console for details.");
    });
}
